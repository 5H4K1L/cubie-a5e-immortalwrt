# Cubie A5E 1 GB: bootloader extraction

Boot-chain components extracted (read-only) from `Immortal-1GB-DRAM-A5E-LuCi-XLR8.img`
(SHA-256 `b06846f3779c76ce18c7d9bf41560f2abef2e94e4cae4c78c7e6c129e12c3019`, 337641746 bytes).

**Binary to reuse in the ImmortalWrt build:** `bootloader/integrated/u-boot-sunxi-with-spl.bin`
(896329 bytes, SHA-256 `2cc42f955c5d0c5042b307ff67b646aa8d49740e2b0680a411506738b03e73eb`), written at byte offset 8192 (`bs=1024 seek=8`) of the image file.
It is the Allwinner eGON SPL + a FIT containing U-Boot 2026.01 (Armbian-flavoured), TF-A BL31 v2.13.0 and the Cubie A5E DTB.

Start with `EXTRACTION_REPORT.md` (inventory, offsets, hashes, confirmed vs. unverified findings, recommendation).

| Directory | Contents |
|---|---|
| `bootloader/integrated/` | complete SPL + u-boot.itb binary |
| `bootloader/spl/`, `uboot/`, `trusted-firmware/` | components cut out of the integrated binary (SPL, FIT, U-Boot proper, BL31) |
| `bootloader/scp/`, `other/` | `NOT_FOUND.txt` only: no SCP, boot0, boot_package or DRAM blob exists in the image |
| `device-tree/` | U-Boot DTB, kernel DTB, FIT structure dumps |
| `boot-config/` | `BOOT.SCR`, its script text, the kernel FIT `uImage`, U-Boot's built-in default environment |
| `firmware/` | inventory of rootfs firmware/modules (not early-boot; binaries not copied) |
| `partition-info/` | MBR sector, FAT16/ext4 info, machine-readable `extraction-manifest.json` |
| `image/` | image info, OpenWrt trailer metadata, selected rootfs metadata files |
| `scripts/` | extraction script, equivalent `dd` commands, verification script |

Verify: `sha256sum -c SHA256SUMS`  and  `sh scripts/verify_against_image.sh <image>`.
Nothing here was flashed to hardware, and the GitHub repository was not modified.
