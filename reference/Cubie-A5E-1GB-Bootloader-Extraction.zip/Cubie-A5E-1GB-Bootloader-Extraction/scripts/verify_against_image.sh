#!/bin/sh
# Re-cut each bootloader component from the original image by offset and compare byte-for-byte with the packaged file.
# Read-only. Usage: sh verify_against_image.sh IMAGE.img   (run from the package root)
IMG="$1"; [ -f "$IMG" ] || { echo "usage: $0 IMAGE.img"; exit 2; }
chk() { # file offset length
  if dd if="$IMG" bs=1 skip="$2" count="$3" 2>/dev/null | cmp -s - "$1"; then echo "OK   $1  (offset $2, length $3)"; else echo "FAIL $1"; FAIL=1; fi; }
chk bootloader/integrated/u-boot-sunxi-with-spl.bin 8192 896329
chk bootloader/spl/sunxi-spl.bin 8192 49152
chk bootloader/uboot/u-boot.itb 57344 847177
chk bootloader/uboot/u-boot-proper.bin 57652 775128
chk bootloader/trusted-firmware/bl31.bin 832972 41124
chk device-tree/u-boot-allwinner_sun55i-a527-cubie-a5e.dtb 874256 28952
chk partition-info/mbr-sector0.bin 0 512
chk image/image-trailer-metadata.bin 337641472 274
echo "source image sha256: $(sha256sum "$IMG" | cut -d' ' -f1)  (expected b06846f3779c76ce18c7d9bf41560f2abef2e94e4cae4c78c7e6c129e12c3019)"
exit ${FAIL:-0}
