# How the extraction was performed (all read-only)

The image was only ever opened for reading. Nothing was flashed or written to a block device.

    python3 scripts/extract_bootchain.py Immortal-1GB-DRAM-A5E-LuCi-XLR8.img OUTDIR     # reproduces everything in this package

Equivalent manual `dd` commands for the main components (offsets verified from on-disk headers, see EXTRACTION_REPORT.md):

    IMG=Immortal-1GB-DRAM-A5E-LuCi-XLR8.img
    # integrated SPL + u-boot.itb : offset 8192, length 896329
    dd if=$IMG of=u-boot-sunxi-with-spl.bin bs=1 skip=8192  count=896329
    # SPL (eGON.BT0)             : offset 8192, length 49152
    dd if=$IMG of=sunxi-spl.bin             bs=1 skip=8192  count=49152
    # u-boot.itb (FIT)           : offset 57344, length 847177
    dd if=$IMG of=u-boot.itb                bs=1 skip=57344 count=847177
    # BL31 (TF-A) inside the FIT : offset 832972, length 41124
    dd if=$IMG of=bl31.bin                  bs=1 skip=832972 count=41124
    # U-Boot proper inside FIT   : offset 57652, length 775128
    dd if=$IMG of=u-boot-proper.bin         bs=1 skip=57652 count=775128
    # U-Boot DTB inside FIT      : offset 874256, length 28952
    dd if=$IMG of=u-boot.dtb                bs=1 skip=874256 count=28952
    # MBR sector
    dd if=$IMG of=mbr-sector0.bin bs=512 count=1
    # trailing OpenWrt metadata  : offset 337641472, length 274
    dd if=$IMG of=trailer.bin bs=1 skip=337641472 count=274

Boot partition (FAT16, partition 1, offset 1048576) files BOOT.SCR and uImage, and the ext4 rootfs
(partition 2, offset 23068672) metadata files were read with the built-in FAT16 parser in the script and with
`debugfs -R "cat <path>"` on a scratch copy of the partition (never on the original image).

Verify the package:        cd Cubie-A5E-1GB-Bootloader-Extraction && sha256sum -c SHA256SUMS
Verify against the image:  sh scripts/verify_against_image.sh /path/to/Immortal-1GB-DRAM-A5E-LuCi-XLR8.img
