#!/usr/bin/env python3
"""
Read-only extraction of the boot chain from an Allwinner A527 (Radxa Cubie A5E) OpenWrt/ImmortalWrt SD image.

  usage: extract_bootchain.py IMAGE.img OUTDIR

* The source image is only ever opened with mode 'rb'. Nothing is written to any block device.
* Offsets are discovered from on-disk structures (MBR, eGON header, FDT/FIT headers, FAT16, ext4 via debugfs -R)
  and cross-checked (eGON checksum, FIT totalsize), not assumed.
* Needs Python 3 (stdlib only). Optional: `debugfs` (e2fsprogs) to read the ext4 rootfs read-only.
"""
import sys, os, struct, hashlib, zlib, json, subprocess, shutil, tempfile, lzma

SRC, OUT = sys.argv[1], sys.argv[2]
SECT = 512
f = open(SRC, 'rb')
SIZE = os.fstat(f.fileno()).st_size
def rd(off, n): f.seek(off); return f.read(n)
def sha(b): return hashlib.sha256(b).hexdigest()
def put(rel, data, mode='wb'):
    p = os.path.join(OUT, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, mode).write(data); return p
manifest = {'source_size': SIZE}
h = hashlib.sha256()
f.seek(0)
for chunk in iter(lambda: f.read(1 << 20), b''): h.update(chunk)
manifest['source_sha256'] = h.hexdigest()

# ---------- MBR ----------
mbr = rd(0, 512)
assert mbr[510:512] == b'\x55\xaa', 'no MBR signature'
parts = []
for i in range(4):
    e = mbr[446 + 16 * i: 462 + 16 * i]
    boot, ptype = e[0], e[4]
    lba, nsec = struct.unpack_from('<II', e, 8)
    if ptype: parts.append(dict(n=i + 1, boot=boot == 0x80, type=hex(ptype), start=lba, sectors=nsec,
                                offset=lba * SECT, length=nsec * SECT))
manifest['disk_signature'] = '0x%08x' % struct.unpack_from('<I', mbr, 440)[0]
manifest['mbr_bootcode_all_zero'] = not any(mbr[:440])
manifest['partitions'] = parts
last_end = max(p['offset'] + p['length'] for p in parts)
manifest['bytes_after_last_partition'] = SIZE - last_end
put('partition-info/mbr-sector0.bin', mbr)

# ---------- unpartitioned areas ----------
def nonzero(off, n):
    b = rd(off, n); nz = [i for i, x in enumerate(b) if x]
    return (off + nz[0], off + nz[-1]) if nz else None
manifest['pre_partition_nonzero_range(after MBR)'] = nonzero(SECT, parts[0]['offset'] - SECT)
manifest['gap_p1_p2_nonzero_range'] = nonzero(parts[0]['offset'] + parts[0]['length'],
                                              parts[1]['offset'] - parts[0]['offset'] - parts[0]['length'])

# ---------- FDT / FIT parser ----------
def fdt_parse(d, base=0):
    m, tot, offs, offstr, ver, lc, bc, szstr, szst = struct.unpack_from('>9I', d, base)
    assert m == 0xd00dfeed
    pos, strs = base + offs, base + offstr
    root, stack = None, []
    al = lambda x: (x + 3) & ~3
    while True:
        t = struct.unpack_from('>I', d, pos)[0]; pos += 4
        if t == 1:
            e = d.index(b'\0', pos); n = d[pos:e].decode(); pos = al(e + 1)
            node = {'name': n, 'props': {}, 'kids': []}
            if root is None: root = node
            else: stack[-1]['kids'].append(node)
            stack.append(node)
        elif t == 2: stack.pop()
        elif t == 3:
            ln, no = struct.unpack_from('>II', d, pos); pos += 8
            e = d.index(b'\0', strs + no); pn = d[strs + no:e].decode()
            stack[-1]['props'][pn] = (pos, ln); pos = al(pos + ln)
        elif t == 9: break
    return root, tot
def fdt_dump(d, n, ind=0, out=None):
    out = out if out is not None else []
    out.append(' ' * ind + (n['name'] or '/'))
    for k, (o, l) in n['props'].items():
        v = d[o:o + l]
        if k == 'data': s = '<%d bytes at fdt+0x%x>' % (l, o)
        elif l and l < 100 and v.endswith(b'\0') and all(32 <= c < 127 for c in v[:-1]): s = '"%s"' % v[:-1].decode()
        elif l == 4: s = '0x%x' % struct.unpack('>I', v)[0]
        else: s = '<%d bytes>' % l
        out.append(' ' * ind + '  %s = %s' % (k, s))
    for c in n['kids']: fdt_dump(d, c, ind + 2, out)
    return out
def fit_images(d):
    r, tot = fdt_parse(d)
    imgs = [k for k in r['kids'] if k['name'] == 'images'][0]['kids']
    return r, tot, {n['name']: n for n in imgs}

# ---------- Allwinner SPL (eGON.BT0) at 0x2000 ----------
SPL_OFF = 0x2000
hdr = rd(SPL_OFF, 0x80)
assert hdr[4:12] == b'eGON.BT0', 'no eGON.BT0 at 0x2000'
spl_len = struct.unpack_from('<I', hdr, 16)[0]
spl = bytearray(rd(SPL_OFF, spl_len))
stored = struct.unpack_from('<I', spl, 12)[0]
struct.pack_into('<I', spl, 12, 0x5F0A6C39)
calc = sum(struct.unpack('<%dI' % (spl_len // 4), bytes(spl))) & 0xffffffff
manifest['spl'] = dict(offset=SPL_OFF, length=spl_len, egon_checksum_stored=hex(stored), egon_checksum_computed=hex(calc),
                       checksum_ok=stored == calc, spl_magic=rd(SPL_OFF + 0x14, 4).decode('latin1'),
                       header_fel_uenv_len=
                           [hex(x) for x in struct.unpack_from('<4I', hdr, 0x1c)],
                       fel_script_address=hex(struct.unpack_from('<I', hdr, 0x18)[0]),
                       dt_name_offset=hex(struct.unpack_from('<I', hdr, 0x20)[0]),
                       dram_size_field_in_header=struct.unpack_from('<I', hdr, 0x24)[0],
                       boot_media_field=struct.unpack_from('<I', hdr, 0x28)[0],
                       spl_dt_name=rd(SPL_OFF + struct.unpack_from('<I', hdr, 0x20)[0], 64).split(b'\0')[0].decode(),
                       sha256=sha(rd(SPL_OFF, spl_len)))
put('bootloader/spl/sunxi-spl.bin', rd(SPL_OFF, spl_len))

# ---------- u-boot.itb (FIT) directly after SPL ----------
ITB_OFF = SPL_OFF + spl_len
assert rd(ITB_OFF, 4) == b'\xd0\x0d\xfe\xed', 'no FDT/FIT magic after SPL'
itb_len = struct.unpack_from('>I', rd(ITB_OFF, 8), 4)[0]
itb = rd(ITB_OFF, itb_len)
root, tot, imgs = fit_images(itb)
fit = dict(offset=ITB_OFF, length=itb_len, sha256=sha(itb), images={})
put('bootloader/uboot/u-boot.itb', itb)
put('device-tree/u-boot-itb-fit-structure.txt', '\n'.join(fdt_dump(itb, root)) + '\n', 'w')
names = {'uboot': 'bootloader/uboot/u-boot-proper.bin', 'atf': 'bootloader/trusted-firmware/bl31.bin',
         'fdt-1': 'device-tree/u-boot-allwinner_sun55i-a527-cubie-a5e.dtb'}
for k, n in imgs.items():
    o, l = n['props']['data']; blob = itb[o:o + l]
    ent = dict(itb_offset=o, image_offset=ITB_OFF + o, length=l, sha256=sha(blob), file=names.get(k))
    if 'load' in n['props']:
        lo, ll = n['props']['load']; ent['load_addr'] = '0x%x' % int.from_bytes(itb[lo:lo + ll], 'big')
    fit['images'][k] = ent
    if k in names: put(names[k], blob)
manifest['u_boot_itb'] = fit
manifest['integrated_total'] = dict(offset=SPL_OFF, length=spl_len + itb_len,
                                    sha256=sha(rd(SPL_OFF, spl_len + itb_len)))
put('bootloader/integrated/u-boot-sunxi-with-spl.bin', rd(SPL_OFF, spl_len + itb_len))

# ---------- default env block embedded in U-Boot proper ----------
import re
ub = itb[imgs['uboot']['props']['data'][0]:][:imgs['uboot']['props']['data'][1]]
a = ub.find(b'bootdelay=1\0'); tok = re.compile(rb'^[A-Za-z_][A-Za-z0-9_]*=')
ok = lambda t: tok.match(t) and all(32 <= c < 127 or c in (9, 10) for c in t)
s = a
while True:
    j = ub.rfind(b'\0', 0, s - 1)
    if ok(ub[j + 1:s - 1]): s = j + 1
    else: break
e = a
while True:
    k = ub.find(b'\0', e)
    if ok(ub[e:k]): e = k + 1
    else: break
env = [x.decode('latin1') for x in ub[s:e].split(b'\0') if x]
put('boot-config/uboot-builtin-default-env.txt',
    '# Derived text: NUL-separated key=value block found inside U-Boot proper at u-boot-proper.bin+%d (%d bytes).\n'
    '# Boundaries found heuristically (contiguous printable KEY=VALUE tokens); treat as informational.\n' % (s, e - s)
    + '\n'.join(env) + '\n', 'w')
manifest['uboot_env_block'] = dict(uboot_proper_offset=s, length=e - s, vars=len(env))

# ---------- FAT16 boot partition (read-only parse) ----------
p1 = parts[0]; d1 = rd(p1['offset'], p1['length'])
bps, spc, res, nfat, rootent, _, _, spf = struct.unpack_from('<HBHBHHBH', d1, 11)
rootsec = (rootent * 32 + bps - 1) // bps
rootoff = (res + nfat * spf) * bps; dataoff = rootoff + rootsec * bps; cs = spc * bps
fat = d1[res * bps: res * bps + spf * bps]
def chain(c):
    o = b''
    while 2 <= c < 0xFFF8:
        p = dataoff + (c - 2) * cs; o += d1[p:p + cs]; c = struct.unpack_from('<H', fat, c * 2)[0]
    return o
def ents(buf):
    lfn = ''; r = []
    for i in range(0, len(buf), 32):
        e = buf[i:i + 32]
        if e[0] == 0: break
        if e[0] == 0xE5: lfn = ''; continue
        if e[11] == 0x0F:
            lfn = (e[1:11] + e[14:26] + e[28:32]).decode('utf-16le').split('\0')[0].split('\uffff')[0] + lfn; continue
        nm = e[:8].decode('latin1').strip(); ex = e[8:11].decode('latin1').strip()
        r.append((lfn or nm + ('.' + ex if ex else ''), e[11], struct.unpack_from('<H', e, 26)[0], struct.unpack_from('<I', e, 28)[0])); lfn = ''
    return r
listing = []; files = {}
def walk(es, path=''):
    for n, at, c, sz in es:
        if n in ('.', '..') or at & 8: continue
        if at & 0x10: listing.append(path + '/' + n + '/'); walk(ents(chain(c)), path + '/' + n)
        else: listing.append('%s/%s  %d bytes' % (path, n, sz)); files[path + '/' + n] = chain(c)[:sz]
walk(ents(d1[rootoff: rootoff + rootsec * bps]))
put('partition-info/fat16-p1-info.txt',
    'FAT16 partition 1: bytes/sector=%d sectors/cluster=%d reserved=%d FATs=%d root entries=%d sectors/FAT=%d\n'
    'volume serial=%08X label/OEM=%s\n\nFile listing (parsed read-only by extract_bootchain.py):\n%s\n'
    % (bps, spc, res, nfat, rootent, spf, struct.unpack_from('<I', d1, 39)[0], d1[3:11].decode('latin1'), '\n'.join(listing)), 'w')
fatinfo = {}
for path, data in files.items():
    if path.lower() == '/boot.scr':
        put('boot-config/BOOT.SCR', data)
        m, hcrc, ts, sz, la, ep, dcrc, os_, arch, typ, comp = struct.unpack_from('>IIIIIIIBBBB', data, 0)
        body = data[64:64 + sz]
        fatinfo['BOOT.SCR'] = dict(sha256=sha(data), size=len(data), legacy_uimage_magic=hex(m), image_type=typ, payload_crc32_ok=(zlib.crc32(body) & 0xffffffff) == dcrc,
                                   header_crc32_ok=(zlib.crc32(data[:4] + b'\0\0\0\0' + data[8:64]) & 0xffffffff) == hcrc, build_timestamp=ts)
        put('boot-config/BOOT.SCR.script-text.txt', body[8:], 'wb')   # 8-byte size table precedes script text
    if path.lower() == '/uimage':
        put('boot-config/uImage', data)
        r2, t2, im2 = fit_images(data)
        put('device-tree/uImage-fit-structure.txt', '\n'.join(fdt_dump(data, r2)) + '\n', 'w')
        kd, kl = im2['kernel-1']['props']['data']; dd, dl = im2['fdt-1']['props']['data']
        put('device-tree/kernel-fit-radxa_cubie-a5e.dtb', data[dd:dd + dl])
        k = data[kd:kd + kl]
        kimg = lzma.LZMADecompressor(format=lzma.FORMAT_ALONE).decompress(k)
        i = kimg.find(b'Linux version')
        fatinfo['uImage'] = dict(sha256=sha(data), size=len(data), format='FIT (flattened image tree)', total_size_field=t2,
                                 kernel_description=fdt_dump(data, im2['kernel-1']) [1:3], kernel_compressed=kl, kernel_decompressed=len(kimg),
                                 kernel_uncompressed_sha256=sha(kimg), kernel_version=kimg[i:i + 160].split(b'\n')[0].decode('latin1'),
                                 embedded_kernel_config=(kimg.find(b'IKCFG_ST') >= 0), dtb_sha256=sha(data[dd:dd + dl]), dtb_size=dl)
manifest['fat_files'] = fatinfo
manifest['fat_listing'] = listing

# ---------- trailing image metadata (OpenWrt fwtool) ----------
trailer = rd(last_end, SIZE - last_end)
if trailer: put('image/image-trailer-metadata.bin', trailer)
manifest['trailer'] = dict(offset=last_end, length=len(trailer), sha256=sha(trailer),
                           json_text=trailer[trailer.find(b'{'):trailer.rfind(b'}') + 1].decode('latin1') if b'{' in trailer else None)
if manifest['trailer']['json_text']:
    put('image/image-trailer-metadata.json', manifest['trailer']['json_text'] + '\n', 'w')

# ---------- ext4 rootfs: read selected small files via debugfs (read-only) ----------
p2 = parts[1]
if shutil.which('debugfs'):
    tmp = tempfile.mkdtemp(); fs = os.path.join(tmp, 'p2.img')
    with open(fs, 'wb') as o: o.write(rd(p2['offset'], p2['length']))
    def dfs(cmd): return subprocess.run(['debugfs', '-R', cmd, fs], capture_output=True).stdout
    put('partition-info/ext4-p2-superblock.txt', dfs('stats').split(b'Group 0')[0].decode('latin1'), 'w')
    want = ['/etc/openwrt_release', '/etc/openwrt_version', '/usr/lib/os-release', '/etc/board.json', '/etc/fstab',
            '/lib/upgrade/platform.sh', '/lib/uboot-envtools.sh', '/lib/upgrade/keep.d/uboot-envtools',
            '/etc/board.d/01_leds', '/etc/board.d/02_network', '/etc/board.d/05_compat-version',
            '/etc/board.d/05_fw_defaults', '/etc/board.d/99-default_network']
    for w in want:
        b = dfs('cat ' + w)
        if b: put('image/rootfs-metadata' + w, b)
    inv = ['# Firmware files present in the rootfs (inventory only - binaries not copied; none are part of the early boot chain)',
           '# sha256  size  path']
    fwdir = os.path.join(tmp, 'fw'); os.makedirs(fwdir)
    dfs('rdump /lib/firmware ' + fwdir)
    for dp, dn, fn in sorted(os.walk(fwdir)):
        for x in sorted(fn):
            p = os.path.join(dp, x); b = open(p, 'rb').read()
            inv.append('%s  %d  /lib/firmware/%s' % (sha(b), len(b), os.path.relpath(p, os.path.join(fwdir, 'firmware'))))
    mods = dfs('ls /lib/modules/6.18.34').decode('latin1').split()
    inv.append('\n# Kernel modules directory /lib/modules/6.18.34: %d entries (names only):' % len(mods))
    inv.append(' '.join(mods))
    put('firmware/FIRMWARE_INVENTORY.txt', '\n'.join(inv) + '\n', 'w')
    shutil.rmtree(tmp)
json.dump(manifest, open(os.path.join(OUT, 'partition-info', 'extraction-manifest.json'), 'w'), indent=2, default=str)
print(json.dumps(manifest, indent=2, default=str)[:6000])
