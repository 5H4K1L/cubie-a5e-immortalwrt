Extracted from Immortal-1GB-DRAM-A5E-LuCi-XLR8.img (Allwinner A527 / Cubie A5E)
- u-boot-sunxi-with-spl.bin : SPL (eGON.BT0) + u-boot.itb, as found at byte offset 8192 (sector 16)
- boot0_spl.bin             : SPL only (offset 8192, 49152 bytes)
- u-boot.itb                : U-Boot FIT image (offset 57344, 847177 bytes)

Write back to an SD card (replace /dev/sdX, this does not touch the partition table):
  dd if=u-boot-sunxi-with-spl.bin of=/dev/sdX bs=1024 seek=8 conv=notrunc
